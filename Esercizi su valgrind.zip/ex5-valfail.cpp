#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv)
{
  char str[10];
  cin >> str;
  cout << str << endl;

  return 0;
}